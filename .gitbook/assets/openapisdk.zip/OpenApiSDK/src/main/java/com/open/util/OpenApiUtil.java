package com.open.util;

import com.alibaba.fastjson.JSONObject;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.Md5Crypt;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.*;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import sun.security.provider.MD5;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

/**
 * 开放平台工具类
 * @author dutingyu
 */
public class OpenApiUtil {

    private static final Log log = LogFactory.getLog(OpenApiUtil.class);

    /** 访问密钥 */
    private static final String ACCESS_KEY = "";
    /** 访问密匙 */
    private static final String ACCESS_SECRET = "";

    /** 请求超时时间(单位毫秒) */
    private static final int CONNECTION_REQUEST_TIMEOUT = 5000;
    /** 连接超时时间(单位毫秒) */
    private static final int CONNECT_TIMEOUT = 5000;
    /** socket读写超时时间(单位毫秒) */
    private static final int SOCKET_TIMEOUT = 5000;

    /** 请求配置 */
    private static final RequestConfig config = RequestConfig.custom()
            .setConnectionRequestTimeout(CONNECTION_REQUEST_TIMEOUT)
            .setConnectTimeout(CONNECT_TIMEOUT)
            .setSocketTimeout(SOCKET_TIMEOUT)
            .build();

    /** 算法 */
    private static final String ALGORITHM = "AES/ECB/PKCS5Padding";

    /**
     * GET请求
     *
     * @return
     */
    public static ResultDTO apiGet(String url) {
        HttpGet httpGet = new HttpGet(url);
        // 请求配置
        httpGet.setConfig(config);
        // 设置请求头数据
        httpGet.setHeader("access-key", ACCESS_KEY);
        httpGet.setHeader("access-sign", getSign());
        String result = "";
        try {
            CloseableHttpResponse closeableHttpResponse = HttpClients.createDefault().execute(httpGet);
            HttpEntity httpEntity = closeableHttpResponse.getEntity();
            result = EntityUtils.toString(httpEntity);
            return JSONObject.parseObject(result, ResultDTO.class);
        } catch (Exception e) {
            log.error(String.format("开放平台接口请求异常,接口地址:%s,返回结果:%s,异常信息:%s", url, result,e));
            return new ResultDTO(ResultDTO.FAILED, "请求异常", null);
        }
    }

    /**
     * POST请求
     *
     * @param url  请求地址
     * @param body body数据
     * @return
     */
    public static ResultDTO apiPost(String url, String body) {
        HttpPost httpPost = new HttpPost(url);
        // 请求配置
        httpPost.setConfig(config);
        // 设置请求头数据
        httpPost.setHeader("access-key", ACCESS_KEY);
        httpPost.setHeader("access-sign", getSign());
        String result = "";
        try {
            // body数据
            httpPost.setEntity(new StringEntity(body, ContentType.APPLICATION_JSON));
            // 执行请求
            HttpEntity httpEntity = HttpClients.createDefault().execute(httpPost).getEntity();
            result = EntityUtils.toString(httpEntity);
            return JSONObject.parseObject(result, ResultDTO.class);
        } catch (Exception e) {
            log.error(String.format("开放平台接口请求异常,接口地址:%s,请求参数%s,返回结果:%s,异常信息:%s", url, body, result,e));
            return new ResultDTO(ResultDTO.FAILED, "请求异常", null);
        }
    }

    /**
     * PUT请求
     *
     * @param url  请求地址
     * @param body body数据
     * @return
     */
    public static ResultDTO apiPut(String url, String body) {
        HttpPut httpPut = new HttpPut(url);
        // 请求配置
        httpPut.setConfig(config);
        // 设置请求头数据
        httpPut.setHeader("access-key", ACCESS_KEY);
        httpPut.setHeader("access-sign", getSign());
        String result = "";
        try {
            // body数据
            httpPut.setEntity(new StringEntity(body, ContentType.APPLICATION_JSON));
            // 执行请求
            HttpEntity httpEntity = HttpClients.createDefault().execute(httpPut).getEntity();
            result = EntityUtils.toString(httpEntity);
            return JSONObject.parseObject(result, ResultDTO.class);
        } catch (Exception e) {
            log.error(String.format("开放平台接口请求异常,接口地址:%s,请求参数%s,返回结果:%s,异常信息:%s", url, body, result,e));
            return new ResultDTO(ResultDTO.FAILED, "请求异常", null);
        }
    }

    /**
     * DELETE请求
     *
     * @param url 请求地址
     * @return
     */
    public static ResultDTO apiDelete(String url) {
        HttpDelete httpDelete = new HttpDelete(url);
        // 请求配置
        httpDelete.setConfig(config);
        // 设置请求头数据
        httpDelete.setHeader("access-key", ACCESS_KEY);
        httpDelete.setHeader("access-sign", getSign());
        String result = "";
        try {
            // 执行请求
            HttpEntity httpEntity = HttpClients.createDefault().execute(httpDelete).getEntity();
            result = EntityUtils.toString(httpEntity);
            return JSONObject.parseObject(result, ResultDTO.class);
        } catch (Exception e) {
            log.error(String.format("开放平台接口请求异常,接口地址:%s,返回结果:%s,异常信息:%s", url, result,e));
            return new ResultDTO(ResultDTO.FAILED, "请求异常", null);
        }
    }

    /**
     * 获取签名
     *
     * @return
     */
    public static String getSign() {
        return encrypt(getTimestamp(), ACCESS_SECRET);
    }

    /**
     * 获取毫秒时间戳
     *
     * @return
     */
    public static String getTimestamp() {
        return String.valueOf(System.currentTimeMillis());
    }

    /**
     * AES加密字符串
     *
     * @param content  需要被加密的字符串
     * @param password 加密需要的密码
     * @return 密文
     */
    public static String encrypt(String content, String password) {
        try {
            // 转换为转换为AES专用密钥AES专用密钥
            SecretKeySpec key = new SecretKeySpec(password.getBytes(), "AES");
            // 创建密码器
            Cipher cipher = Cipher.getInstance(ALGORITHM);
            // 初始化为加密模式的密码器
            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] byteContent = content.getBytes("UTF-8");
            // 加密
            byte[] result = cipher.doFinal(byteContent);
            //转换加密后产生的特殊字符，比如"+"
            String accessKeySecret = Base64.encodeBase64String(result);
            try {
                accessKeySecret = URLEncoder.encode(accessKeySecret, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                log.error(String.format("AES加密异常, content: %s, password: %s, err: %s", content, password, e));
            }
            return accessKeySecret;
        } catch (Exception e) {
            log.error(String.format("AES加密异常, content: %s, password: %s, err: %s", content, password, e));
            return null;
        }

    }

}
