package com.open.example;

import com.open.util.OpenApiUtil;
import com.open.util.ResultDTO;

/**
 * @author dutingyu
 */
public class SimpleExample {

    /**
     * 请求示例
     *
     * @param args
     */
      public static void main(String[] args) {
          String body = "{}";
          //分组查询接口
          ResultDTO resultByGet = OpenApiUtil.apiGet("http://localhost/api");
          //POST请求 body默认内容格式为application/json
          //ResultDTO resultByPost = OpenApiUtil.apiPost("http://localhost/api", body);
          // PUT请求 body默认内容格式为application/json
          //ResultDTO resultByPut = OpenApiUtil.apiPut("http://localhost/api", body);
          // DELETE 参数拼在链接后面
          //ResultDTO resultByDelete = OpenApiUtil.apiDelete("http://localhost/api?id=1");
    }

}
