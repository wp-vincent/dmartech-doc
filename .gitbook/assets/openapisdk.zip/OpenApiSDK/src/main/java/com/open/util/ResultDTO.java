package com.open.util;

import java.io.Serializable;

/**
 * 操作结果DTO
 * @param <T> 数据的类型
 */
public class ResultDTO<T> implements Serializable {
    /** 成功状态码 */
    public static final Integer SUCCESSFUL = 200;
    /** 失败状态码 */
    public static final Integer FAILED = 500;

    /**  结果码  **/
    private int code = FAILED;
    /**  结果描述  */
    private String message;
    /**  数据  **/
    private T data;

    public ResultDTO(int code, String message, T data) {
        this.code = code;
        this.message = message;
        this.data = data;
    }

    public int getCode() {
        return code;
    }

    public ResultDTO setCode(int code) {
        this.code = code;
        return this;
    }

    public String getMessage() {
        return message;
    }

    public ResultDTO setMessage(String message) {
        this.message = message;
        return this;
    }

    public T getData() {
        return data;
    }

    public ResultDTO setData(T data) {
        this.data = data;
        return this;
    }

    @Override
    public String toString() {
        return "ResultDTO{" +
                "code=" + code +
                ", message='" + message + '\'' +
                ", data=" + data +
                '}';
    }
}
